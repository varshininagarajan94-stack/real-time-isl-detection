# Kai Pesum — கைப் பேசும்

Real-time Tamil Sign Language → text & speech, built for the deaf community.

The full app runs **in your browser**:
- 📷 `getUserMedia` live camera feed
- 🤲 MediaPipe Holistic (pose + face + 2 hands) landmark extraction
- 🧠 30-frame sequence buffer → LSTM gesture classifier
- 🪄 Smoothing + confidence threshold + sentence builder
- 🗣️ Tamil text + Web Speech API speech synthesis (`ta-IN`)

This repo contains the **Python training scaffold** that produces the LSTM
weights consumed by the web app. The frontend ships with a deterministic
heuristic fallback so it works end-to-end before you train.

## Pipeline

```
Camera → MediaPipe Holistic → Landmarks (30 frames × 1629)
       → LSTM (this repo) → Class probabilities
       → Smoothing + threshold → Sentence builder → Tamil caption + TTS
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 1. Record training data

For each gesture class, record ~30 sequences of 30 frames each:

```bash
python record.py --label hello       --num 30
python record.py --label thank_you   --num 30
python record.py --label idle        --num 60   # background / no-sign
# …repeat for every class in model/gesture_classes.py
```

Sequences are saved as `data/sequences/<label>/<idx>.npy` with shape
`(30, 1629)`.

## 2. Train the LSTM

```bash
python -m model.train --data-dir ./data/sequences --epochs 50
```

Outputs `exported/gesture_lstm.h5` (best-by-val-accuracy checkpoint).

## 3. Export to TensorFlow.js

```bash
tensorflowjs_converter \
    --input_format=keras \
    exported/gesture_lstm.h5 \
    exported/tfjs_model
```

## 4. Wire into the web app

Copy the exported model into the frontend:

```bash
cp -r exported/tfjs_model <web-app>/public/models/gesture_lstm
```

Then in `src/lib/gesture-model.ts` replace the heuristic `predictSequence`
implementation with TF.js inference:

```ts
import * as tf from "@tensorflow/tfjs";
const model = await tf.loadLayersModel("/models/gesture_lstm/model.json");
const probs = await (model.predict(
  tf.tensor3d([sequence.map(flattenFrame)])
) as tf.Tensor).data();
```

## Class registry

Both Python and TypeScript share the same ordered class list:

| ID | English | தமிழ் |
|---:|---|---|
| 0 | (idle) | — |
| 1 | hello | வணக்கம் |
| 2 | thank you | நன்றி |
| 3 | yes | ஆம் |
| 4 | no | இல்லை |
| 5 | water | தண்ணீர் |
| 6 | food | உணவு |
| 7 | help | உதவி |
| 8 | please | தயவு செய்து |
| 9 | sorry | மன்னிக்கவும் |
| 10 | good | நல்லது |
| 11 | bad | கெட்டது |
| 12 | I | நான் |
| 13 | you | நீ |
| 14 | name | பெயர் |
| 15 | love | அன்பு |

To add classes, edit **both** `model/gesture_classes.py` and
`src/lib/gestures.ts` keeping IDs identical.

## File map

```
model/
  __init__.py
  gesture_classes.py   # shared class registry
  model.py             # build_keras_model() + TorchGestureLSTM
  train.py             # CLI training loop, checkpointing, augmentation
record.py              # webcam → .npy sequence recorder
requirements.txt
```

## License

MIT — built with care for accessibility.

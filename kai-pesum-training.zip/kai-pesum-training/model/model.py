"""LSTM gesture classifier.

Two equivalent implementations are provided:
  * `build_keras_model()`  -> tf.keras model (recommended for export to TF.js)
  * `TorchGestureLSTM`     -> PyTorch implementation for research / training

Either path produces a softmax over `NUM_CLASSES` from a 30-frame sequence
of MediaPipe Holistic landmarks (1629 features per frame).

To deploy in the browser:
  1. Train Keras model with `train.py`
  2. `tensorflowjs_converter --input_format=keras saved_model.h5 ./tfjs_model`
  3. Drop `tfjs_model/` into the frontend `public/models/gesture_lstm/`
  4. Replace the heuristic in `src/lib/gesture-model.ts` with `tf.loadLayersModel`
"""

from __future__ import annotations

from .gesture_classes import FEATURES_PER_FRAME, NUM_CLASSES, SEQUENCE_LENGTH


def build_keras_model(
    sequence_length: int = SEQUENCE_LENGTH,
    feature_dim: int = FEATURES_PER_FRAME,
    num_classes: int = NUM_CLASSES,
    lstm_units: int = 128,
    dropout: float = 0.3,
):
    """Return a compiled tf.keras LSTM gesture classifier."""
    import tensorflow as tf
    from tensorflow.keras import layers, models

    inputs = layers.Input(shape=(sequence_length, feature_dim), name="landmarks")
    x = layers.Masking(mask_value=0.0)(inputs)
    x = layers.LSTM(lstm_units, return_sequences=True)(x)
    x = layers.Dropout(dropout)(x)
    x = layers.LSTM(lstm_units // 2)(x)
    x = layers.Dropout(dropout)(x)
    x = layers.Dense(64, activation="relu")(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="probs")(x)

    model = models.Model(inputs, outputs, name="gesture_lstm")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


# ---------------------------------------------------------------------------
# Optional PyTorch implementation
# ---------------------------------------------------------------------------
try:
    import torch
    from torch import nn

    class TorchGestureLSTM(nn.Module):
        def __init__(
            self,
            feature_dim: int = FEATURES_PER_FRAME,
            num_classes: int = NUM_CLASSES,
            hidden: int = 128,
            dropout: float = 0.3,
        ) -> None:
            super().__init__()
            self.lstm1 = nn.LSTM(feature_dim, hidden, batch_first=True)
            self.drop1 = nn.Dropout(dropout)
            self.lstm2 = nn.LSTM(hidden, hidden // 2, batch_first=True)
            self.drop2 = nn.Dropout(dropout)
            self.fc1 = nn.Linear(hidden // 2, 64)
            self.act = nn.ReLU()
            self.fc2 = nn.Linear(64, num_classes)

        def forward(self, x: "torch.Tensor") -> "torch.Tensor":
            x, _ = self.lstm1(x)
            x = self.drop1(x)
            x, _ = self.lstm2(x)
            x = self.drop2(x[:, -1, :])  # last timestep
            x = self.act(self.fc1(x))
            return self.fc2(x)  # logits — apply softmax outside

except ImportError:  # PyTorch optional
    torch = None  # type: ignore

    class TorchGestureLSTM:  # type: ignore[no-redef]
        def __init__(self, *_, **__):
            raise RuntimeError("Install torch to use TorchGestureLSTM")

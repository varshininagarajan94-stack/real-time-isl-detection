"""Tamil Sign Language gesture class registry.

Mirror of `src/lib/gestures.ts` in the web frontend. Index order MUST match
so trained model outputs align with the JS-side label table.
"""

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class GestureClass:
    id: int
    key: str
    english: str
    tamil: str
    role: str  # "word" | "control"


GESTURE_CLASSES: List[GestureClass] = [
    GestureClass(0, "idle", "(idle)", "", "control"),
    GestureClass(1, "hello", "hello", "வணக்கம்", "word"),
    GestureClass(2, "thank_you", "thank you", "நன்றி", "word"),
    GestureClass(3, "yes", "yes", "ஆம்", "word"),
    GestureClass(4, "no", "no", "இல்லை", "word"),
    GestureClass(5, "water", "water", "தண்ணீர்", "word"),
    GestureClass(6, "food", "food", "உணவு", "word"),
    GestureClass(7, "help", "help", "உதவி", "word"),
    GestureClass(8, "please", "please", "தயவு செய்து", "word"),
    GestureClass(9, "sorry", "sorry", "மன்னிக்கவும்", "word"),
    GestureClass(10, "good", "good", "நல்லது", "word"),
    GestureClass(11, "bad", "bad", "கெட்டது", "word"),
    GestureClass(12, "i", "I", "நான்", "word"),
    GestureClass(13, "you", "you", "நீ", "word"),
    GestureClass(14, "name", "name", "பெயர்", "word"),
    GestureClass(15, "love", "love", "அன்பு", "word"),
]

NUM_CLASSES = len(GESTURE_CLASSES)
IDLE_ID = 0

# MediaPipe Holistic landmark counts
N_POSE = 33
N_FACE = 468
N_HAND = 21
LANDMARKS_PER_FRAME = N_POSE + N_FACE + N_HAND * 2  # 543
FEATURES_PER_FRAME = LANDMARKS_PER_FRAME * 3        # 1629
SEQUENCE_LENGTH = 30


def label_for(class_id: int) -> str:
    return GESTURE_CLASSES[class_id].tamil or GESTURE_CLASSES[class_id].english

"""Training scaffold for the Kai Pesum gesture LSTM.

Expected dataset layout (after running `record.py` or your own collector):

    data/
      sequences/
        hello/000.npy   # shape (30, 1629)
        hello/001.npy
        thank_you/000.npy
        ...
        idle/000.npy

Each `.npy` file holds a single landmark sequence flattened per frame.

Usage:
    python -m model.train --data-dir ./data/sequences --epochs 50

After training, export to TensorFlow.js:
    pip install tensorflowjs
    tensorflowjs_converter \\
        --input_format=keras exported/gesture_lstm.h5 \\
        ./exported/tfjs_model
Then copy `exported/tfjs_model/` into the web app at
`public/models/gesture_lstm/` and load it from `gesture-model.ts`.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import List, Tuple

import numpy as np

from .gesture_classes import (
    FEATURES_PER_FRAME,
    GESTURE_CLASSES,
    NUM_CLASSES,
    SEQUENCE_LENGTH,
)
from .model import build_keras_model


def _load_dataset(root: Path) -> Tuple[np.ndarray, np.ndarray]:
    """Load sequences from `root/<class_key>/*.npy`."""
    xs: List[np.ndarray] = []
    ys: List[int] = []
    for cls in GESTURE_CLASSES:
        cls_dir = root / cls.key
        if not cls_dir.exists():
            print(f"[warn] missing class directory: {cls_dir}")
            continue
        for npy_path in sorted(cls_dir.glob("*.npy")):
            arr = np.load(npy_path).astype(np.float32)
            if arr.shape != (SEQUENCE_LENGTH, FEATURES_PER_FRAME):
                print(f"[skip] bad shape {arr.shape} for {npy_path}")
                continue
            xs.append(arr)
            ys.append(cls.id)
    if not xs:
        raise RuntimeError(
            f"No training data found under {root}. "
            "Record sequences with record.py first."
        )
    return np.stack(xs), np.array(ys, dtype=np.int64)


def _augment(x: np.ndarray, jitter: float = 0.01) -> np.ndarray:
    """Add small Gaussian jitter on non-zero landmarks (data augmentation)."""
    mask = (x != 0).astype(np.float32)
    noise = np.random.normal(0.0, jitter, size=x.shape).astype(np.float32)
    return x + noise * mask


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data/sequences"))
    parser.add_argument("--out", type=Path, default=Path("exported/gesture_lstm.h5"))
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--val-split", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    np.random.seed(args.seed)
    import tensorflow as tf  # local import to keep CLI snappy

    tf.random.set_seed(args.seed)

    print(f"[info] loading dataset from {args.data_dir}")
    X, y = _load_dataset(args.data_dir)
    print(f"[info] loaded {len(X)} sequences across {NUM_CLASSES} classes")

    # shuffle
    perm = np.random.permutation(len(X))
    X, y = X[perm], y[perm]

    # validation split
    n_val = int(len(X) * args.val_split)
    X_val, y_val = X[:n_val], y[:n_val]
    X_train, y_train = X[n_val:], y[n_val:]

    # augmentation on train
    X_train_aug = np.concatenate([X_train, _augment(X_train)], axis=0)
    y_train_aug = np.concatenate([y_train, y_train], axis=0)

    model = build_keras_model()
    model.summary()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(
            str(args.out), save_best_only=True, monitor="val_accuracy", mode="max"
        ),
        tf.keras.callbacks.EarlyStopping(
            patience=8, restore_best_weights=True, monitor="val_accuracy", mode="max"
        ),
        tf.keras.callbacks.ReduceLROnPlateau(patience=4, factor=0.5, monitor="val_loss"),
    ]

    model.fit(
        X_train_aug,
        y_train_aug,
        validation_data=(X_val, y_val),
        epochs=args.epochs,
        batch_size=args.batch_size,
        callbacks=callbacks,
        verbose=2,
    )

    print(f"[done] best model saved to {args.out}")
    print(
        "[next] Convert to TF.js:\n"
        f"  tensorflowjs_converter --input_format=keras {args.out} "
        f"{args.out.parent}/tfjs_model"
    )


if __name__ == "__main__":
    main()

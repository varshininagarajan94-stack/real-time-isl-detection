"""Record landmark sequences for training.

Captures 30-frame windows of MediaPipe Holistic landmarks from your webcam
and writes them to `data/sequences/<class_key>/<index>.npy`.

Usage:
    python record.py --label hello --num 30
    python record.py --label thank_you --num 30
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import cv2
import numpy as np

import mediapipe as mp

from model.gesture_classes import (
    FEATURES_PER_FRAME,
    GESTURE_CLASSES,
    SEQUENCE_LENGTH,
)


def _flatten(landmarks, count: int) -> np.ndarray:
    out = np.zeros(count * 3, dtype=np.float32)
    if landmarks is None:
        return out
    for i, lm in enumerate(landmarks.landmark[:count]):
        out[i * 3] = lm.x
        out[i * 3 + 1] = lm.y
        out[i * 3 + 2] = lm.z
    return out


def _frame_features(results) -> np.ndarray:
    return np.concatenate(
        [
            _flatten(results.pose_landmarks, 33),
            _flatten(results.face_landmarks, 468),
            _flatten(results.left_hand_landmarks, 21),
            _flatten(results.right_hand_landmarks, 21),
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True, help="gesture class key, e.g. hello")
    parser.add_argument("--num", type=int, default=30, help="how many sequences to record")
    parser.add_argument("--out-root", type=Path, default=Path("data/sequences"))
    args = parser.parse_args()

    valid_keys = {g.key for g in GESTURE_CLASSES}
    if args.label not in valid_keys:
        raise SystemExit(f"Unknown label '{args.label}'. Valid: {sorted(valid_keys)}")

    out_dir = args.out_root / args.label
    out_dir.mkdir(parents=True, exist_ok=True)
    existing = len(list(out_dir.glob("*.npy")))
    print(f"[info] {existing} existing sequences for '{args.label}'")

    holistic = mp.solutions.holistic.Holistic(
        model_complexity=1, min_detection_confidence=0.5, min_tracking_confidence=0.5
    )
    cap = cv2.VideoCapture(0)
    try:
        for i in range(args.num):
            print(f"\n[seq {i + 1}/{args.num}] Get ready in 3s…")
            time.sleep(3)
            buf = np.zeros((SEQUENCE_LENGTH, FEATURES_PER_FRAME), dtype=np.float32)
            for f in range(SEQUENCE_LENGTH):
                ok, frame = cap.read()
                if not ok:
                    raise RuntimeError("camera read failed")
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = holistic.process(rgb)
                buf[f] = _frame_features(results)
                cv2.putText(
                    frame,
                    f"{args.label}  {f + 1}/{SEQUENCE_LENGTH}",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 255, 255),
                    2,
                )
                cv2.imshow("record", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    raise KeyboardInterrupt
            idx = existing + i
            np.save(out_dir / f"{idx:03d}.npy", buf)
            print(f"  saved {out_dir}/{idx:03d}.npy")
    finally:
        cap.release()
        cv2.destroyAllWindows()
        holistic.close()


if __name__ == "__main__":
    main()
